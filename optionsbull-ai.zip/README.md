# OptionsBull AI Indicator Bot

## Components
- TradingView indicator with AI logic (Pine Script)
- Python Flask API for signal generation
- Telegram alert integration
- Backtesting script with Backtrader

## Setup Instructions
1. Train your model and save to `model/optionsbull_ai_model.pkl`
2. Run Flask API with `python app/api.py`
3. Use TradingView Pine Script from `indicator/optionsbull.pine`
4. Configure Telegram bot in `app/telegram_alerts.py`
5. Run backtest with `python backtest/backtest.py`
